employee 
email shruthi2525@gmail.com
password Shru@123

admin
email admin@gmail.com
password 12345

backend npm start
frontend npm run dev
